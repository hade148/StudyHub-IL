
  # Hebrew RTL Academic Dashboard

  This is a code bundle for Hebrew RTL Academic Dashboard. The original project is available at https://www.figma.com/design/xrmM6fJcLdM5qIvB23BzS6/Hebrew-RTL-Academic-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  